import java.awt.Color;
import java.awt.Graphics;
/**
 * A Wall tile extends Tile, and represents a wall that the player and 
 * monsters cannot pass through.
 * @author Montek
 */

public class Wall extends Tile {
	
	public Wall(int row, int column) {
		super(row, column);
	}

	/**
	 * returns false since walls aren't passable
	 */
	public boolean isPassable() {
		return false;
	}

	/**
	 * draws wall
	 */
	public void drawTile(Graphics g) {
		g.setColor(Color.black);
		g.fillRect(getRow(), getCol(), 25, 25);	
	}

	



}
