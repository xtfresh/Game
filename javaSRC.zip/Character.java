import java.awt.Graphics;

/**
 * Characters represent living objects in the game, such as players and 
 * monsters
 * @author Montek
 *
 */
public abstract class Character {
	
	protected Game game;
	private int row;
	private int col;
	
	
	public Character(Game game, int row, int col) {
		this.game = game;
		this.row = row;
		this.col = col;
	}
	
	/**
	 * draws the character
	 * @param g graphics component
	 */
	public abstract void draw(Graphics g);
	
	/**
	 * updated location of character when timer is fired
	 * 
	 */
	public abstract void update();
	
	/**
	 * @return returns row location
	 */
	public int getRow(){
		return row;
	}
	/**
	 * updates row
	 * @param row
	 */
	public void setRow(int drow){
		this.row += drow;
	}
	
	/**
	 * 
	 * @return integer value column 
	 */
	public int getCol(){
		return col;
	}
	
	/**
	 * updates Column 
	 * @param col
	 */
	public void setCol(int dcol){
		this.col += dcol;
	}
	
	public boolean runsInto(Character c){
		if (c.getRow()==row && c.getCol()==col)
			return true;
		else return false;
	}
	
}
