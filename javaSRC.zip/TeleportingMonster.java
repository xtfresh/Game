
public class TeleportingMonster extends Monsters {
	private int dRow;
	private int dCol;
	private int moveDir;
	
	public TeleportingMonster(Game game,int row, int col,int dRow, int dCol) {
		super(game, row, col);
		this.dRow = dRow;
		this.dCol = dCol;
		moveDir = 0;
	}

	public TeleportingMonster(Game game) {
		super(game);
		
		
	}
	
	public void update(){
		dRow = 0;
		dCol = 0;
		moveDir = 1 + (int)(Math.random() * (4));
		moveDir = 1 + (int)(Math.random() * (4));
		switch(moveDir){
			case 1:if(getRow()+3<game.getLevel().getTileArray().length){dRow = 3; dCol = 0;}break;
			case 2:if(getRow()-3>0)dRow = -3;dCol = 0;break;
			case 3:if(getRow()+3<game.getLevel().getTileArray()[0].length){dCol = 3;dRow = 0;}break;
			case 4:if(getCol()-3>0){dCol = -3;dRow = 0;}break;
			
		}
		
		if(game.getLevel().getTileArray()[getCol()+dCol][getRow()+dRow].isPassable()){
			setRow(dRow);
			setCol(dCol);
		}
	}

}
