import java.awt.Graphics;

/**
 * Items represent the things on the level that the player can pick up
 * @author Montek
 *
 */
public abstract class Item {
	private int value;
	
	public Item(int val){
		value = val;
	}
	
	/**
	 * draw method to be implemented by subclasses
	 * @param g Graphics object	
	 * @param x x location
	 * @param y y location
	 */
	public abstract void draw(Graphics g, int x, int y);
	
	/**
	 * Returns value
	 * @return value of item
	 */
	public int getValue(){
		return value;
	}
	
}
