import java.awt.Color;
import java.awt.Graphics;

/**
 * Floor tile extends Tile, and represents spaces that the monsters and
 * player can move through.
 * @author Montek
 *
 */
public class Floor extends Tile {
	protected Item item;
	private boolean hasItem;
	public Floor(int row, int col, Item item) {
		super(row, col);
		this.item = item;
		hasItem = true;
	}
	
	public Floor(int row, int col){
		super(row,col);
		hasItem = false;
	}
	public boolean hasItem(){
		return hasItem;
	}
	/**
	 * @return item that floor holds and sets item to null
	 */
	public Item collectItem(){
		hasItem = false;
		Item itemR = item;
		item = null;
		return itemR;
	}

	/**
	 * returns true since this tile type is always passable
	 */
	public boolean isPassable() {
		return true;
	}

	/**
	 * draws the floor
	 */
	public void drawTile(Graphics g) {
		g.setColor(Color.red);
		if(item != null){
			g.drawRect(getRow(), getCol(), width, height);
			g.setColor(Color.green);
			g.fillRect(getRow()+(25/4),getCol()+(25/4),width/2,height/2);
		}else
			g.drawRect(getRow(), getCol(), width, height);
	}

}
