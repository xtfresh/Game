import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;
/**
 * The LevelPanel represents a single level and the GUI
 * @author Montek
 *
 */

public class LevelPanel extends JPanel {
	Game game;
	
	
	public LevelPanel(Game game){
		this.game = game;
		setFocusable(true);
		addKeyListener(new DirectionListener());
	}
	
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		game.getLevel().draw(g);
		game.getPlayer().draw(g);
		for(int i=0;i<game.getMonList().size();i++){
			game.getMonList().get(i).draw(g);
		}
	}
	

	private class DirectionListener implements KeyListener{
		public void keyPressed (KeyEvent event){
			switch (event.getKeyCode()){
				case KeyEvent.VK_UP:
					game.getPlayer().move(0,-1);
	                break;
	            case KeyEvent.VK_DOWN:
	            	game.getPlayer().move(0,1);
	                break;
	            case KeyEvent.VK_LEFT:
	            	game.getPlayer().move(-1,0);
	                break; 
	            case KeyEvent.VK_RIGHT:
	            	game.getPlayer().move(1,0);
	                break;
	        }
			
			repaint();
			
			
			
		}
	      
		public void keyTyped(KeyEvent e){}
		public void keyReleased(KeyEvent e){}
	}
	
	
}
		

			
	
