import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.JLabel;

/**
 * Contains the main method. It is the gate-keeper of the 
 * game, containing Player, Level, and Monster references. Most other classes 
 * contain a reference to Game, as it allows them to interact with the player, 
 * monsters, and level.
 * @author Montek Singh
 * @version 1.0
 */
public class Game {
	private Level lvl;
	private Level lvl2;
	private Player p1;
	private ArrayList<Monsters> monList;
	private static JLabel status;
	public static JLabel score;
	private LevelPanel lvlPanel;
	private Timer timer;
	private int itemsLeft;
	private boolean levelBeaten;
	
	public Game(){
		
		lvl = new Level(this, new char[][]{{'x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x'},
										   {'x','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','x'},
										   {'x','o','i','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','g','o','x'},
										   {'x','o','i','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','g','o','x'},
										   {'x','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','g','o','x'},
										   {'x','o','o','o','o','o','o','o','o','o','o','x','o','o','o','o','o','o','o','g','o','x'},
										   {'x','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','g','o','x'},
										   {'x','o','o','o','o','o','o','o','x','o','o','o','x','o','o','o','o','o','o','g','o','x'},
										   {'x','o','o','o','o','o','o','o','x','x','o','o','o','x','o','o','o','o','o','g','o','x'},
										   {'x','o','o','o','o','o','o','o','o','o','o','o','o','o','x','o','o','o','o','g','o','x'},
										   {'x','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','g','o','x'},
										   {'x','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','g','o','x'},
										   {'x','o','o','o','o','o','o','o','o','o','o','x','x','o','o','o','o','o','o','g','o','x'},
										   {'x','o','o','o','o','o','o','o','o','o','o','x','o','o','o','o','o','o','o','g','o','x'},
										   {'x','o','o','o','o','o','o','o','o','o','o','x','o','o','o','o','o','o','o','g','o','x'},
										   {'x','o','o','o','o','o','o','o','o','o','o','x','o','o','o','o','o','o','o','g','o','x'},
										   {'x','o','o','o','o','o','o','o','o','o','o','x','o','o','o','o','o','o','o','g','o','x'},
										   {'x','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','g','o','x'},
										   {'x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x'}});
		
		
		lvl2 = new Level(this, new char[][]{{'x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x'},
				   							{'x','o','o','o','i','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','x'},
				   							{'x','o','o','o','i','o','o','o','o','o','o','o','o','o','o','o','o','o','o','g','o','x'},
				   							{'x','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','g','o','x'},
				   							{'x','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','g','o','x'},
				   							{'x','o','o','o','o','o','o','o','o','o','o','x','o','o','o','o','o','o','o','g','o','x'},
				   							{'x','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','g','o','x'},
				   							{'x','o','o','o','o','x','x','o','x','o','o','o','x','o','o','o','o','o','o','g','o','x'},
				   							{'x','o','o','o','o','o','x','o','x','x','o','o','o','x','o','o','o','o','o','g','o','x'},
				   							{'x','o','o','o','o','o','x','o','o','o','o','o','o','o','x','o','o','o','o','g','o','x'},
				   							{'x','o','o','o','o','o','x','o','o','o','o','o','o','o','o','o','o','o','o','g','o','x'},
				   							{'x','o','o','o','o','o','x','o','o','o','o','o','o','o','o','o','o','o','o','g','o','x'},
				   							{'x','o','o','o','o','o','x','o','o','o','o','x','x','o','o','o','o','o','o','g','o','x'},
				   							{'x','o','o','o','o','o','o','o','o','o','o','x','o','o','o','o','o','o','o','g','o','x'},
				   							{'x','o','o','o','o','o','o','o','o','o','o','x','o','o','o','o','o','o','o','g','o','x'},
				   							{'x','o','o','o','o','o','o','o','o','o','o','x','o','o','o','o','o','o','o','g','o','x'},
				   							{'x','o','o','o','o','o','o','o','o','o','o','x','o','o','o','o','o','o','o','g','o','x'},
				   							{'x','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','g','o','x'},
				   							{'x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x','x'}});

		
		p1 = new Player(this, 1, 1);
		monList = new ArrayList<Monsters>();
		monList.add(new SimpleMonster(this, 2,2, 1, 1));
		monList.add(new TeleportingMonster(this, 5,15, 1, 1));
		itemsLeft = lvl.getNumItems();
		itemsLeft = lvl2.getNumItems();
		status = new JLabel("Gems Left: "+itemsLeft);
		score = new JLabel("Score: "+p1.getScore());
		lvlPanel = new LevelPanel(this);
		timer = new Timer(1000, new TimerListener());
		timer.setDelay(300);
		timer.start();
		levelBeaten = false;
	}
	public void win(){
		timer.stop();
		levelBeaten = true;
		if(levelBeaten){
			System.out.println("WIN! level 1");
			levelBeaten = false;
			lvl = lvl2;
			itemsLeft = lvl.getNumItems();
			timer.start();
		}
		
	}
	public void lose(){
		timer.stop();
		System.out.println("LOSE!");
		lvlPanel.setFocusable(false);
		
	}
	public void updateState(){
		if (!(getLevel().getTileArray()[p1.getCol()][p1.getRow()] instanceof FakeWalls))
			if(((Floor) getLevel().getTileArray()[p1.getCol()][p1.getRow()]).hasItem()){
				p1.setScore(((Floor)(getLevel().getTileArray()[p1.getCol()][p1.getRow()])).collectItem().getValue());
				itemsLeft--;
			}
		
		
		score.setText("Score: "+p1.getScore());
		status.setText("Status: "+itemsLeft);
	}
	
	/**
	 * returns player reference
	 * @return p1 player
	 */
	public Player getPlayer(){
		return p1;
	}
	
	/**
	 * returns reference to level
	 */
	public Level getLevel(){
		if(levelBeaten())
			return lvl2;
		return lvl;
	}
	
	public ArrayList<Monsters> getMonList(){
		return monList;
	}
	public class TimerListener implements ActionListener{
		public void actionPerformed(ActionEvent e){
			for(int i=0;i<monList.size();i++){
				monList.get(i).update();
				if(monList.get(i).getRow()==p1.getRow()&&monList.get(i).getCol()==p1.getCol())
					lose();
				if(p1.getScore()==lvl.getNumItems())
					win();
			}
			lvlPanel.repaint();
			
			
		}
		
	}
	
	/**
	 * returns lvlPanel reference
	 * @return
	 */
	public JPanel getPanel(){
		return lvlPanel;
	}
	
	public static void main(String [] args){
		JFrame frame = new JFrame ("Paint!");
	    frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	    Game game = new Game();
	    frame.add(game.getPanel());
	    frame.setSize(600, 600);
	    frame.setVisible(true);
	    JPanel panel = new JPanel();
	    panel.setLayout(new FlowLayout());
	    panel.add(status);
	    panel.add(score);
	    frame.add(panel, BorderLayout.SOUTH);
	}
	public boolean levelBeaten() {
		// TODO Auto-generated method stub
		return levelBeaten;
	}
	

}
