import java.awt.Color;
import java.awt.Graphics;

/**
 * Monster represents the monsters of the game. It extends Character, 
 * but since there can be many different types of monsters, Monster is abstract.
 * @author Montek
 *
 */
public abstract class Monsters extends Character {

	public Monsters(Game game, int row, int col) {
		super(game, row, col);
	}
	
	public Monsters(Game game){
		super(game, (int)(Math.random()*(5)), (int)(Math.random()*(5)));
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.yellow);
		g.fillRect(getRow()*25, getCol()*25,25,25);

	}
}
