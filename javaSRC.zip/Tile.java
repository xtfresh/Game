import java.awt.Graphics;

/**
 * Tile represents a space on the level. Therefore, the level class will 
 * contain a 2D array of Tiles. The exact type of Tile may end up being a Floor, 
 * Wall, or some other subclass. Each Tile is responsible for displaying itself.
 * @author Montek
 *
 */
public abstract class Tile {
	protected static int width = 25;
	protected static int height = 25;
	private int row;
	private int column;
	
	public Tile(int row, int column){
		this.row = row;
		this.column = column;
	}
	
	/**
	 * @return returns true if the tile is passable, false otherwise
	 */
	public abstract boolean isPassable();
	
	/**
	 * draws tile
	 * @param g graphics object
	 * @param startX start location x
	 * @param startY start location y
	 */
	public abstract void drawTile(Graphics g);
	
	/**
	 * @return returns row location
	 */
	public int getRow(){
		return row;
	}
	
	/**
	 * @return returns row location
	 */
	public int getCol(){
		return column;
	}
	

}
