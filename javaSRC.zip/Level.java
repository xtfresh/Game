import java.awt.Graphics;

/**
 * The level holds the 2D array of tiles, and determines movement restrictions. 
 * @author Montek
 * 
 */
public class Level {
	
	private Tile[][] tileArray;	
	private int numItems;
	private Game game;
	public Level(Game game, char[][] levelRepresentation) {
		tileArray = new Tile[levelRepresentation.length][levelRepresentation[0].length];
		
		for(int row =0;row<levelRepresentation.length;row++)
			for(int col = 0;col<levelRepresentation[0].length;col++)
				if(levelRepresentation[row][col] == 'o')
					tileArray[row][col] = new Floor(col*25,row*25);
				else if(levelRepresentation[row][col] == 'x')
					tileArray[row][col] = new Wall(col*25, row*25);
				else if(levelRepresentation[row][col] == 'g'){
					tileArray[row][col] = new Floor(col*25, row*25, new Gem());
					numItems++;
				}
				else if(levelRepresentation[row][col] == 'i'){
					tileArray[row][col] = new FakeWalls(col*25, row*25);
				}
				
				
		
		this.game = game;
	}
	


	public void draw(Graphics g){
		for(int row =0;row<tileArray.length;row++)
			for(int col = 0;col<tileArray[0].length;col++)
				tileArray[row][col].drawTile(g);
	}
	public Tile[][] getTileArray(){
		return tileArray;
	}
	
	public int getNumItems(){
		return numItems;
	}

}
