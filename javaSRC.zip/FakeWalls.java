
public class FakeWalls extends Wall {

	public FakeWalls(int row, int column) {
		super(row, column);
		// TODO Auto-generated constructor stub
	}
	
	public boolean isPassable(){
		return true;
	}

	
	

}
