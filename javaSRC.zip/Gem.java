import java.awt.Color;
import java.awt.Graphics;

/**
 * A subclass of Item, these represent simple pickups that give the user points.
 * @author Montek
 *
 */
public class Gem extends Item {
	
	public Gem() {
		super(1);
	}

	/**
	 * draws gem onto the panel
	 */
	public void draw(Graphics g, int x, int y) {
		g.setColor(Color.green);
		g.fillOval(x, y, 12, 12);
	}
	
}
