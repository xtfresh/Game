import java.awt.Color;
import java.awt.Graphics;

/**
 * Player represents the player that the user will control. It extends character.
 * @author Montek
 *
 */
public class Player extends Character {
	
	private int score;
	
	public Player(Game game, int row, int col){
		super(game, row, col);
		score = 0;
	}
	
	/**
	 * moves the player in the inputted direction. 
	 * First, check that the move is legal, i.e., that the player is moving into a 
	 * passable tile, and that the player is not moving off the level. Next, actually 
	 * move the player to that tile, and collect the item that was on the tile. If 
	 * there was an item, it should update the score. Then, check to see if the 
	 * player ran into any monsters. Finally, if there are no gems left, the user 
	 * should win.
	 * @param dRow new row to move to
	 * @param dCol new col to move to
	 */ 
	public void move(int dRow, int dCol){
		if(!(dRow>0&&getRow()==game.getLevel().getTileArray().length)||!(dRow<0&&getRow()==0))
			if(game.getLevel().getTileArray()[getCol()+dCol][getRow()+dRow].isPassable()){
				setRow(dRow);
				setCol(dCol);
				game.updateState();
				
			}
	}

					
					
		
	public void draw(Graphics g) {
		g.setColor(Color.blue);	
		g.fillRect(getRow()*25, getCol()*25, 25, 25);
	}

	/**
	 * unimplemented method from character
	 */
	public void update() {}

	public void setScore(int value) {
		score+=value;
		
	}

	public int getScore() {
		// TODO Auto-generated method stub
		return score;
	}

}
